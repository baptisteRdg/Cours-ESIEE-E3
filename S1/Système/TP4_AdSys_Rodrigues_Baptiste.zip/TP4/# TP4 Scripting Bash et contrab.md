# TP4 Scripting Bash et contrab

## Exercice 1

### Quel est l'effet de shift ?
shift permet de décaler les variables passé en arguments vers la gauche, le deuxième devient premier, le troisième devient deuxième etc...

## Exercice 2   